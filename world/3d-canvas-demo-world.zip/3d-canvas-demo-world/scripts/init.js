Hooks.on("3DCanvasInit", (canvas3d) => { 
    canvas3d.sharing.shareMap = () => { 
        return ui.notifications.error("Sharing is disabled in the demo world.");
    }

    ChatMessage.create({
        whisper: [game.user.id],
        content: 'Welcome to the 3D Canvas Demo Server!<hr>The "Forest Road" scene is setup with Fog of War and Automatic Lighting! Try changing time of day with SmallTime!<hr>For a quick start, create a new scene and check the "Quick 3D Scene" Checkbox!<br /><br />Check the wiki: https://wiki.theripper93.com/levels-3d-preview<br /><br />Video Tutorials: https://youtube.com/playlist?list=PLbNUuLLqMgaBfNAyYb6mhg4pR4bPcHXqM',
    });

});

Hooks.on("init", () => { 
    FilePicker.upload = () => ui.notifications.error("You cannot upload files in the demo world");

    Object.defineProperty(FilePicker.prototype, "canUpload", {
        get: () => {return false}
    })
})